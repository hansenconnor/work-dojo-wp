<h3 class="frm_left_label">
	<?php esc_html_e( 'License Key', 'formidable' ); ?>
</h3>
<div class="frm_with_left_label">
	<?php include( FrmAppHelper::plugin_path() . '/classes/views/shared/errors.php' ); ?>
	<?php if ( $show_creds_form ) { ?>
		<?php $edd_update->pro_cred_form(); ?>
	<?php } ?>
</div>
<div class="clear"></div>
